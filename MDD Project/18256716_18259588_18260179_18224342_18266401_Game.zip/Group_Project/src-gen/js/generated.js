/* this file was generated */

var generated = {
	
	node_tmlP4dE_EeidIsBYxiXZzw: function (callback) {
		generated.node_v8LOQdE_EeidIsBYxiXZzw(callback);
	},
	
	node_tml28dE_EeidIsBYxiXZzw: function (callback) {
		callback("You Survived!");
	}, 
	
	node_f9AwdE_EeidIsBYxiXZzw: function (callback) {
		callback("You died. (Phase 1)");
	}, 
	
	node_AS7aQdFAEeidIsBYxiXZzw: function (callback) {
		callback("You died. (Phase 2)");
	}, 
	
	node_DH_70dFAEeidIsBYxiXZzw: function (callback) {
		callback("You died. (Phase 3)");
	}, 
	
	node_v8LOQdE_EeidIsBYxiXZzw: function (callback) {
		generated.node_7kw4UdBKEeiR_cqVyDtPpQ(function(exitLabel) {
			if (exitLabel == "You died..") {
				generated.node_v8NDcdE_EeidIsBYxiXZzw(callback);
			} 
			else if (exitLabel == "You died...") {
				generated.node_v8NqgdE_EeidIsBYxiXZzw(callback);
			} 
			else if (exitLabel == "You open the door and you see corpses and trash everywhere. Theres no walking corpses. Lucky. You need to get back home and find your daughter.") {
				generated.node_v8O4odE_EeidIsBYxiXZzw(callback);
			} 
		})
	}, 
	
	node_7kw4UdBKEeiR_cqVyDtPpQ: function (callback) {
		generated.node_To38IdBMEeiR_cqVyDtPpQ(callback);
	},
	
	node_MIhTodBNEeiR_cqVyDtPpQ: function (callback) {
		callback("You died...");
	}, 
	
	node_zvoD4dBREeiR_cqVyDtPpQ: function (callback) {
		callback("You died..");
	}, 
	
	node_wRJf8dBTEeiR_cqVyDtPpQ: function (callback) {
		callback("You open the door and you see corpses and trash everywhere. Theres no walking corpses. Lucky. You need to get back home and find your daughter.");
	}, 
	
	node_YBk3MdBLEeiR_cqVyDtPpQ: function (callback) {
		runtime.clear("./backgroundImages/hospitalroom.jpg", "You're waking up. Your head hurts.");
		runtime.setDefaultBranch(function() {
			generated.node_15uysNBLEeiR_cqVyDtPpQ(callback);
		});
	}, 
	
	node_15uysNBLEeiR_cqVyDtPpQ: function (callback) {
		runtime.clear("./backgroundImages/hospitalroom.jpg", "You see a plain hospital room.");
		runtime.setDefaultBranch(function() {
			generated.node_6Mw4sNBMEeiR_cqVyDtPpQ(callback);
		});
	}, 
	
	node_To38IdBMEeiR_cqVyDtPpQ: function (callback) {
		runtime.clear("./backgroundImages/black.jpg", "You're in coma.");
		runtime.addOptionBranch("Just 5 more minutes.", function () {
			generated.node_MIhTodBNEeiR_cqVyDtPpQ(callback);
		});
		runtime.addOptionBranch("Open Eyes.", function () {
			generated.node_YBk3MdBLEeiR_cqVyDtPpQ(callback);
		});
		runtime.setCountdownBranch(20000, true, function() {
			generated.node_MIhTodBNEeiR_cqVyDtPpQ(callback);
		});
	}, 
	
	node_6Mw4sNBMEeiR_cqVyDtPpQ: function (callback) {
		runtime.clear("./backgroundImages/hospitalroom.jpg", "There's dead, dried flowers on the table beside you.");
		runtime.setDefaultBranch(function() {
			generated.node_WcYwIdBNEeiR_cqVyDtPpQ(callback);
		});
	}, 
	
	node_WcYwIdBNEeiR_cqVyDtPpQ: function (callback) {
		runtime.clear("./backgroundImages/hospitalroom.jpg", "You don't see or hear anyone.");
		runtime.addOptionBranch("Try to stand up.", function () {
			generated.node_eVrnodBNEeiR_cqVyDtPpQ(callback);
		});
	}, 
	
	node_eVrnodBNEeiR_cqVyDtPpQ: function (callback) {
		runtime.clear("./backgroundImages/hospitalroom.jpg", "You fell.");
		runtime.addOptionBranch("Hold the IV drip for support and try to stand up.", function () {
			generated.node_bcW0odBOEeiR_cqVyDtPpQ(callback);
		});
	}, 
	
	node_Y_4LIdBOEeiR_cqVyDtPpQ: function (callback) {
		runtime.clear("./backgroundImages/hallway.jpg", "You open the door and you see an an empty hallway.");
		runtime.addOptionBranch("Walk down the hallway.", function () {
			generated.node_8auTIdBOEeiR_cqVyDtPpQ(callback);
		});
	}, 
	
	node_bcW0odBOEeiR_cqVyDtPpQ: function (callback) {
		runtime.clear("./backgroundImages/hospitalroom.jpg", "You succesfully stood up.");
		runtime.addOptionBranch("Go to the doors.", function () {
			generated.node_Y_4LIdBOEeiR_cqVyDtPpQ(callback);
		});
		runtime.addOptionBranch("Go to the window.", function () {
			generated.node_wnCCodBOEeiR_cqVyDtPpQ(callback);
		});
	}, 
	
	node_wnCCodBOEeiR_cqVyDtPpQ: function (callback) {
		runtime.clear("./backgroundImages/window.jpg", "You see smoke coming out of different parts of the city. There's trash and dead bodies all over the roads. You think to yourself: \"Oh god what happend how long have I been out.\"");
		runtime.addOptionBranch("Walk to the door.", function () {
			generated.node_Y_4LIdBOEeiR_cqVyDtPpQ(callback);
		});
	}, 
	
	node_8auTIdBOEeiR_cqVyDtPpQ: function (callback) {
		runtime.clear("./backgroundImages/hallway.jpg", "There's mess all over the ground. You're standing at the end of the hallway.");
		runtime.setDefaultBranch(function() {
			generated.node_RT_yodBQEeiR_cqVyDtPpQ(callback);
		});
	}, 
	
	node_RT_yodBQEeiR_cqVyDtPpQ: function (callback) {
		runtime.clear("./backgroundImages/doors.jpg", "You look to your left and you see a chained doors. There are strage sounds coming from there and you see a hand reaching from behind of it. There is a half eaten corpse lying in front of the doors. You  suddenly don't feel so good looking at it.");
		runtime.addOptionBranch("Try to hug anyone on the other side.", function () {
			generated.node_zvoD4dBREeiR_cqVyDtPpQ(callback);
		});
		runtime.addOptionBranch("Leave the hospital through the fire exit.", function () {
			generated.node_wRJf8dBTEeiR_cqVyDtPpQ(callback);
		});
	}, 
	
	node_0ZiKYdE_EeidIsBYxiXZzw: function (callback) {
		generated.node_eVsVEdBVEeiR_cqVyDtPpQ(function(exitLabel) {
			if (exitLabel == "The zombies got to you before you got to the car... It was too far away.") {
				generated.node_0ZkmodE_EeidIsBYxiXZzw(callback);
			} 
			else if (exitLabel == "Your reflexes didn't kick in in the right time. You got killed by a random zombie thet got to your house before.") {
				generated.node_0Zl0wdE_EeidIsBYxiXZzw(callback);
			} 
			else if (exitLabel == "You rush out the house and run to the car.") {
				generated.node_0ZnC4dE_EeidIsBYxiXZzw(callback);
			} 
			else if (exitLabel == "You didn't kill the zombie in time and he attacked again. This time you weren't so lucky...") {
				generated.node_0Zo4EdE_EeidIsBYxiXZzw(callback);
			} 
			else if (exitLabel == "The zombies came out to the bushes while you didn't do anything... That wasn't the right time to space out.") {
				generated.node_0ZqGMdE_EeidIsBYxiXZzw(callback);
			} 
			else if (exitLabel == "You got killed by a random zombie that got into the house before. If only you had a weapon to fight with...") {
				generated.node_0ZrUUdE_EeidIsBYxiXZzw(callback);
			} 
		})
	}, 
	
	node_eVsVEdBVEeiR_cqVyDtPpQ: function (callback) {
		generated.node_gBkoEdBVEeiR_cqVyDtPpQ(callback);
	},
	
	node_lDJokdB2EeiawZkkhfNQtg: function (callback) {
		callback("The zombies got to you before you got to the car... It was too far away.");
	}, 
	
	node_iiqsANB6EeiawZkkhfNQtg: function (callback) {
		callback("The zombies came out to the bushes while you didn't do anything... That wasn't the right time to space out.");
	}, 
	
	node_1_YEgdB_EeiawZkkhfNQtg: function (callback) {
		callback("You got killed by a random zombie that got into the house before. If only you had a weapon to fight with...");
	}, 
	
	node_f4DRIdCAEeiawZkkhfNQtg: function (callback) {
		callback("Your reflexes didn't kick in in the right time. You got killed by a random zombie thet got to your house before.");
	}, 
	
	node_w0sYcdCAEeiawZkkhfNQtg: function (callback) {
		callback("You didn't kill the zombie in time and he attacked again. This time you weren't so lucky...");
	}, 
	
	node_l_q6MdCBEeiawZkkhfNQtg: function (callback) {
		callback("You rush out the house and run to the car.");
	}, 
	
	node_gBkoEdBVEeiR_cqVyDtPpQ: function (callback) {
		runtime.clear("./backgroundImages/cars.jpg", "You walk to the parking lot. You need a vehicle to travel in. Choose fast because you hear rustilng in the bushes.");
		runtime.addMatchRectangularRegionBranch(-0.1, -0.1, 0.3, 0.3, function () {
			generated.node_nY6MkdBWEeiR_cqVyDtPpQ(callback);
		});
		runtime.addMatchRectangularRegionBranch(-0.5, 0.0, 0.5, 0.5, function () {
			generated.node_nLQLEdBWEeiR_cqVyDtPpQ(callback);
		});
		runtime.addMatchRectangularRegionBranch(-1.1, -0.1, 0.3, 0.3, function () {
			generated.node_m_loEdBWEeiR_cqVyDtPpQ(callback);
		});
		runtime.setCountdownBranch(10000, true, function() {
			generated.node_iiqsANB6EeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_m_loEdBWEeiR_cqVyDtPpQ: function (callback) {
		runtime.clear("./backgroundImages/cars.jpg", "You chose the left car.");
		runtime.setDefaultBranch(function() {
			generated.node_lDJokdB2EeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_nLQLEdBWEeiR_cqVyDtPpQ: function (callback) {
		runtime.clear("./backgroundImages/cars.jpg", "You chose the car in the middle.");
		runtime.setDefaultBranch(function() {
			generated.node_x_docdB2EeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_nY6MkdBWEeiR_cqVyDtPpQ: function (callback) {
		runtime.clear("./backgroundImages/cars.jpg", "You chose the car on the right.");
		runtime.setDefaultBranch(function() {
			generated.node_LHPqwdB3EeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_x_docdB2EeiawZkkhfNQtg: function (callback) {
		runtime.clear("./backgroundImages/cars.jpg", "The car won't start up. Which one do you check next?");
		runtime.addMatchRectangularRegionBranch(-1.1, -0.1, 0.3, 0.3, function () {
			generated.node_lDJokdB2EeiawZkkhfNQtg(callback);
		});
		runtime.addMatchRectangularRegionBranch(-0.1, -0.1, 0.3, 0.3, function () {
			generated.node_LHPqwdB3EeiawZkkhfNQtg(callback);
		});
		runtime.setCountdownBranch(10000, true, function() {
			generated.node_lDJokdB2EeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_LHPqwdB3EeiawZkkhfNQtg: function (callback) {
		runtime.clear("./backgroundImages/cars.jpg", "The car starts up. As you are starting to move you see a bunch of zombies getting out of the bush behind the car you didn't choose. Lucky.");
		runtime.setDefaultBranch(function() {
			generated.node_Myi5gdB4EeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_Myi5gdB4EeiawZkkhfNQtg: function (callback) {
		runtime.clear("./backgroundImages/driving.gif", "You drive between all the cars left on the road with your exeptional driving. Suddenly you see your house.");
		runtime.setDefaultBranch(function() {
			generated.node_GTnMdB6EeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_6dK9UdB6EeiawZkkhfNQtg: function (callback) {
		runtime.clear("./backgroundImages/house.jpg", "You suddenly hear noises upstairs. You hold up your knife and hurry up the stairs.");
		runtime.setDefaultBranch(function() {
			generated.node_BEvodB_EeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_GTnMdB6EeiawZkkhfNQtg: function (callback) {
		runtime.clear("./backgroundImages/house.jpg", "You stop the car and run up the stairs. The doors are wide open. You walk in. What room do you check?");
		runtime.addOptionBranch("The Garage.", function () {
			generated.node_XkuF0dB8EeiawZkkhfNQtg(callback);
		});
		runtime.addOptionBranch("The Kitchen.", function () {
			generated.node_YzhbQdB8EeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_XkuF0dB8EeiawZkkhfNQtg: function (callback) {
		runtime.clear("./backgroundImages/bat.jpg", "You notice your ultimate engineering creation on the ground.");
		runtime.addMatchCircularRegionBranch(0.8, -0.1, 0.2, function () {
			generated.node_NuAU0NB7EeiawZkkhfNQtg (callback);
		});
		runtime.setDefaultBranch(function() {
			generated.node_tzXK4dB_EeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_YzhbQdB8EeiawZkkhfNQtg: function (callback) {
		runtime.clear("./backgroundImages/kitchen.jpg", "You notice a knife but you don't find anything else there. Where is your daughter?");
		runtime.addMatchCircularRegionBranch(0.8, 0.2, 0.2, function () {
			generated.node_9I5R0NB8EeiawZkkhfNQtg (callback);
		});
		runtime.setDefaultBranch(function() {
			generated.node_tzXK4dB_EeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_zferEdB9EeiawZkkhfNQtg: function (callback) {
		runtime.clear("./backgroundImages/house.jpg", "You suddenly hear noises upstairs. You hold up your bat and hurry up the stairs.");
		runtime.setDefaultBranch(function() {
			generated.node_BEvodB_EeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_tzXK4dB_EeiawZkkhfNQtg: function (callback) {
		runtime.clear("./backgroundImages/house.jpg", "You suddenly hear noises upstairs. You  hurry up the stairs.");
		runtime.setDefaultBranch(function() {
			generated.node_1_YEgdB_EeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_BEvodB_EeiawZkkhfNQtg: function (callback) {
		runtime.clear("./backgroundImages/zombie.jpg", "There is a zombie rushing towards you. DODGE!");
		runtime.addMatchCircularRegionBranch(1.0, 0.0, 0.3, function () {
			generated.node_T3vg8dCAEeiawZkkhfNQtg (callback);
		});
		runtime.setCountdownBranch(4000, true, function() {
			generated.node_f4DRIdCAEeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_T3vg8dCAEeiawZkkhfNQtg: function (callback) {
		runtime.clear("./backgroundImages/zomiemid.jpg", "Nice dodge! Now hit him!");
		runtime.addMatchCircularRegionBranch(0.0, 0.0, 0.4, function () {
			generated.node_wjD14dCAEeiawZkkhfNQtg (callback);
		});
		runtime.setCountdownBranch(4000, true, function() {
			generated.node_w0sYcdCAEeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_wjD14dCAEeiawZkkhfNQtg: function (callback) {
		runtime.clear("./backgroundImages/house.jpg", "You killed the walking corpse. Good Work.");
		runtime.setDefaultBranch(function() {
			generated.node_F0zVMdCBEeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_F0zVMdCBEeiawZkkhfNQtg: function (callback) {
		runtime.clear("./backgroundImages/note.jpg", "You look into Sarah's room and you find a note.");
		runtime.setDefaultBranch(function() {
			generated.node_l_q6MdCBEeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_NuAU0NB7EeiawZkkhfNQtg: function (callback) {
		runtime.addToInventory("Baseball bat", 1, true);
		generated.node_zferEdB9EeiawZkkhfNQtg(callback);
	},
	
	node_9I5R0NB8EeiawZkkhfNQtg: function (callback) {
		runtime.addToInventory("Knife", 1, true);
		generated.node_6dK9UdB6EeiawZkkhfNQtg(callback);
	},
	
	node_5ogJodE_EeidIsBYxiXZzw: function (callback) {
		generated.node_4c3OQdCBEeiawZkkhfNQtg(function(exitLabel) {
			if (exitLabel == "You found the Grandpa and your daughter! congratulations! (Chapter 2 will come out if we sell at least 100 copies)") {
				generated.node_5olpMdE_EeidIsBYxiXZzw(callback);
			} 
			else if (exitLabel == "The car runs out of fuel in the middle of the road and there are zombies all around you. What were you thinking. You're dead.") {
				generated.node_5oneYdE_EeidIsBYxiXZzw(callback);
			} 
			else if (exitLabel == "A big zombie grizzly eats you... Why would you shout?") {
				generated.node_5opTkdE_EeidIsBYxiXZzw(callback);
			} 
		})
	}, 
	
	node_4c3OQdCBEeiawZkkhfNQtg: function (callback) {
		generated.node_GzzeodCCEeiawZkkhfNQtg(callback);
	},
	
	node_fty3AdCCEeiawZkkhfNQtg: function (callback) {
		callback("The car runs out of fuel in the middle of the road and there are zombies all around you. What were you thinking. You're dead.");
	}, 
	
	node_Aa57gdCFEeiawZkkhfNQtg: function (callback) {
		callback("A big zombie grizzly eats you... Why would you shout?");
	}, 
	
	node_ZTQVIdCFEeiawZkkhfNQtg: function (callback) {
		callback("You found the Grandpa and your daughter! congratulations! (Chapter 2 will come out if we sell at least 100 copies)");
	}, 
	
	node_GzzeodCCEeiawZkkhfNQtg: function (callback) {
		runtime.clear("./backgroundImages/highway.jpg", "You get into the car and drive to grandpa's cabin in the woods. Halfway there you notice the fuel is really low. good thing there is a petrol station near. Do you stop there?");
		runtime.addOptionBranch("YES SIR gachiBASS", function () {
			generated.node_aiTCgdCCEeiawZkkhfNQtg(callback);
		});
		runtime.addOptionBranch("No I can push it there when it runs out of fuel.", function () {
			generated.node_fty3AdCCEeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_aiTCgdCCEeiawZkkhfNQtg: function (callback) {
		runtime.clear("./backgroundImages/petrolstation.jpg", "You stop at the petrol station but there is one zombie. You try to take him out.");
		runtime.setDefaultBranch(function() {
			generated.node_BaroYdCDEeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_s2IJwdCDEeiawZkkhfNQtg: function (callback) {
		runtime.clear("./backgroundImages/petrolstation.jpg", "You take out the zombie but the bat breaks in the process. So much for your engineering skills.");
		runtime.setDefaultBranch(function() {
			generated.node_aMKIgNCEEeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_uxtssdCDEeiawZkkhfNQtg: function (callback) {
		runtime.clear("./backgroundImages/petrolstation.jpg", "You take out the zombie but the knife gets stuck and you're not in the mood to try to pull it out.");
		runtime.setDefaultBranch(function() {
			generated.node_adE5YdCEEeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_C5_pkdCEEeiawZkkhfNQtg: function (callback) {
		runtime.clear("./backgroundImages/highway.jpg", "You fill up the petrol tank and get on the road again.");
		runtime.setDefaultBranch(function() {
			generated.node_IDbokdCEEeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_IDbokdCEEeiawZkkhfNQtg: function (callback) {
		runtime.clear("./backgroundImages/forest.jpg", "You reach the forest and get out the car to walk to the cabin. You never understood why there wasn't any roads in that forest but now it gets handy.");
		runtime.setDefaultBranch(function() {
			generated.node_re1KMdCEEeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_re1KMdCEEeiawZkkhfNQtg: function (callback) {
		runtime.clear("./backgroundImages/forest.jpg", "As you're walking you hear rustling in front of you. What do you do?");
		runtime.addOptionBranch("Hide.", function () {
			generated.node_1GJpwdCEEeiawZkkhfNQtg(callback);
		});
		runtime.addOptionBranch("Shout out this is america!", function () {
			generated.node_Aa57gdCFEeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_1GJpwdCEEeiawZkkhfNQtg: function (callback) {
		runtime.clear("./backgroundImages/bush.jpg", "You stay in the bushes for 10min till you can't hear anything anymore and then you get back to walking.");
		runtime.setDefaultBranch(function() {
			generated.node_L19CgdCFEeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_L19CgdCFEeiawZkkhfNQtg: function (callback) {
		runtime.clear("./backgroundImages/forest.jpg", "After another 2 hours of walking you find the cabin.");
		runtime.setDefaultBranch(function() {
			generated.node_UA_KQdCFEeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_UA_KQdCFEeiawZkkhfNQtg: function (callback) {
		runtime.clear("./backgroundImages/cabin.jpg", "You knock on the door...");
		runtime.setDefaultBranch(function() {
			generated.node_ZTQVIdCFEeiawZkkhfNQtg(callback);
		});
	}, 
	
	node_aMKIgNCEEeiawZkkhfNQtg: function (callback) {
		runtime.removeFromInventory("Baseball bat", 1);
		generated.node_C5_pkdCEEeiawZkkhfNQtg(callback);
	},
	
	node_adE5YdCEEeiawZkkhfNQtg: function (callback) {
		runtime.removeFromInventory("Knife", 1);
		generated.node_C5_pkdCEEeiawZkkhfNQtg(callback);
	},
	
	node_03OH0dCCEeiawZkkhfNQtg: function (callback) {
		if (runtime.checkInventory("Knife", 1))
			generated.node_uxtssdCDEeiawZkkhfNQtg(callback);
		else 
			generated.node_s2IJwdCDEeiawZkkhfNQtg(callback);
	}, 
	
	node_BaroYdCDEeiawZkkhfNQtg: function (callback) {
		if (runtime.checkInventory("Baseball bat", 1))
			generated.node_s2IJwdCDEeiawZkkhfNQtg(callback);
		else 
			generated.node_03OH0dCCEeiawZkkhfNQtg(callback);
	}, 
	
	node_v8NDcdE_EeidIsBYxiXZzw: function (callback) {
		generated.node_f9AwdE_EeidIsBYxiXZzw(callback);
	},
	
	node_v8NqgdE_EeidIsBYxiXZzw: function (callback) {
		generated.node_f9AwdE_EeidIsBYxiXZzw(callback);
	},
	
	node_v8O4odE_EeidIsBYxiXZzw: function (callback) {
		generated.node_0ZiKYdE_EeidIsBYxiXZzw(callback);
	},
	
	node_0ZkmodE_EeidIsBYxiXZzw: function (callback) {
		generated.node_AS7aQdFAEeidIsBYxiXZzw(callback);
	},
	
	node_0Zl0wdE_EeidIsBYxiXZzw: function (callback) {
		generated.node_AS7aQdFAEeidIsBYxiXZzw(callback);
	},
	
	node_0ZnC4dE_EeidIsBYxiXZzw: function (callback) {
		generated.node_5ogJodE_EeidIsBYxiXZzw(callback);
	},
	
	node_0Zo4EdE_EeidIsBYxiXZzw: function (callback) {
		generated.node_AS7aQdFAEeidIsBYxiXZzw(callback);
	},
	
	node_0ZqGMdE_EeidIsBYxiXZzw: function (callback) {
		generated.node_AS7aQdFAEeidIsBYxiXZzw(callback);
	},
	
	node_0ZrUUdE_EeidIsBYxiXZzw: function (callback) {
		generated.node_AS7aQdFAEeidIsBYxiXZzw(callback);
	},
	
	node_5olpMdE_EeidIsBYxiXZzw: function (callback) {
		generated.node_tml28dE_EeidIsBYxiXZzw(callback);
	},
	
	node_5oneYdE_EeidIsBYxiXZzw: function (callback) {
		generated.node_DH_70dFAEeidIsBYxiXZzw(callback);
	},
	
	node_5opTkdE_EeidIsBYxiXZzw: function (callback) {
		generated.node_DH_70dFAEeidIsBYxiXZzw(callback);
	},
	
	entry: function () {
		generated.node_tmlP4dE_EeidIsBYxiXZzw(function(exitLabel) {
			runtime.exit(exitLabel);
		});
	}, 

	adventureGameName: "Dazed",
	debugMode: true
};

