var runtime = {

	defaultCallback: undefined, 
	matchTextualInputCallbacks: [], 
	visibleInventory: [], 
	invisibleInventory: [], 
	countDownTimeout: undefined, 
	countDownRemainingTimeInMs: 0, 
	countDownCallback: 0, 
	
	animationDuration: 1000, 
	darkenBackgroundIfImageWasNotLoadAfter: 1000, 
	countDownUpdateFrequency: 1000,

	entry: function () {
		this.visibleInventory = []; 
		this.invisibleInventory = []; 
		generated.entry();
	},
	
	clear: function (backgroundImage, text) {
		var backgroundImageCompletePath = backgroundImage == "" ? undefined : "./images/dynamic/" + backgroundImage; 
		this.newBackgroundImage(backgroundImageCompletePath);
		runtime.defaultCallback = undefined; 
		runtime.matchTextualInputCallbacks = []; 
		runtime.switchScreen("#playScreen");
		$("#text").html("");
		$("#text").css("display", "none");
		$("#optionBranches").css("display", "none");
		$("#optionBranches").html("");
		$("#imageRegions").css("display", "none");
		$("#imageRegions").html("");
		$("#matchTextualInputField").css("display", "none");
		$("#matchTextualInputField").val("");
		$("#matchTextualInputSubmit").css("display", "none");
		$("#matchTextualInput").css("display", "none");
		$("#visibleInentory").html("");
		$("#countdown").css("display", "none");
		clearTimeout(runtime.countDownTimeout);
		if (text != "") {
			$("#text").html(text);
			$("#text").css("display", "block");
		}
		runtime.printVisibleInentory();
	},

	printVisibleInentory: function () {
		$("#visibleInentory").css("display", "none");
		$("#visibleInentory").html("");
		for (var itemName in this.visibleInventory) {
			var amount = this.visibleInventory[itemName];
			if (amount > 0) {
				var newSpan = $("<span></span>");
				newSpan.html(amount + " " + itemName);
				newSpan.addClass("roundBorder");
				var newLi = $("<li></li>");
				newLi.html(newSpan);
				$("#visibleInentory").append(newLi);
				$("#visibleInentory").css("display", "block");
			}
		}
	},

	unit2css: function (units) {
		return (50 * units) + "vh";
	},

	addMatchRectangularRegionBranch: function (x, y, width, height, callback) {
		var newDiv = $("<div></div>");
		newDiv.addClass("matchRegionBranch");
		newDiv.css("left", this.unit2css(x));
		newDiv.css("top", this.unit2css(y));
		newDiv.css("width", this.unit2css(width));
		newDiv.css("height", this.unit2css(height));
		if (generated.debugMode) {
			newDiv.css("background-color", "rgba(0, 0, 255, 0.25)");
		}
		newDiv.click(callback);
		$("#imageRegions").append(newDiv);
		$("#imageRegions").css("display", "block");
	},

	addMatchCircularRegionBranch: function (x, y, radius, callback) {
		var diameter = 2 * radius;
		var newDiv = $("<div></div>");
		newDiv.addClass("matchRegionBranch");
		newDiv.css("left", this.unit2css(x - radius));
		newDiv.css("top", this.unit2css(y - radius));
		newDiv.css("width", this.unit2css(diameter));
		newDiv.css("height", this.unit2css(diameter));
		newDiv.css("border-radius", this.unit2css(radius));
		if (generated.debugMode) {
			newDiv.css("background-color", "rgba(0, 0, 255, 0.25)");
		}
		newDiv.click(callback);
		$("#imageRegions").append(newDiv);
		$("#imageRegions").css("display", "block");
	},

	addOptionBranch: function (optionName, callback) {
		var newLi = $("<li></li>");
		var newButton = $("<input/>");
		newButton.attr("type", "button");
		newButton.addClass("blueButton");
		newButton.addClass("button");
		newButton.addClass("roundBorder");
		newButton.val(optionName);
		newButton.click(callback);
		newLi.html(newButton);
		$("#optionBranches").append(newLi);
		$("#optionBranches").css("display", "block");
	}, 

	setDefaultBranch: function (callback) {
		$("#matchTextualInputSubmit").css("display", "inline-block");
		$("#matchTextualInput").css("display", "inline-block");
		this.defaultCallback = callback;
	}, 

	setCountdownBranch: function (totalTimeInMs, isVisible, callback) {
		if (isVisible) 
			$("#countdown").css("display", "block");
		runtime.countDownCallback = callback;
		runtime.countDownRemainingTimeInMs = totalTimeInMs;
		runtime.countDown();
	}, 

	countDown: function () {
		var remainingTimeFormatted = runtime.formatRemainingTime(runtime.countDownRemainingTimeInMs);
		if (runtime.countDownRemainingTimeInMs <= 0) {
			$("#countdown").html("0");
			if (runtime.countDownCallback != undefined)
				runtime.countDownCallback();
		}
		else {
			$("#countdown").html(remainingTimeFormatted);
			var timeoutLength = runtime.countDownRemainingTimeInMs % runtime.countDownUpdateFrequency;
			if (timeoutLength < 1)
				timeoutLength = runtime.countDownUpdateFrequency;
			runtime.countDownRemainingTimeInMs -= timeoutLength;
			runtime.countDownTimeout = setTimeout(runtime.countDown, timeoutLength);
		}
	}, 

	addMatchTextualInputBranch: function (text, callback) {
		$("#matchTextualInput").css("display", "inline-block");
		$("#matchTextualInputSubmit").css("display", "inline-block");
		$("#matchTextualInputField").css("display", "inline-block");
		$("#matchTextualInputField").val("");
		$("#matchTextualInputField").select();
		this.matchTextualInputCallbacks[text] = callback;
	}, 

	exit: function (exitLabel) {
		$("#startScreenText").html(exitLabel);
		$("#startScreenSubmit").val("Play again");
		this.switchScreen("#startScreen");
		this.newBackgroundImage("./images/startScreenBackground.svg");
		clearTimeout(runtime.countDownTimeout);
	},

	addToInventory: function (itemName, amount, visible) {
		var inventory = visible ? this.visibleInventory : this.invisibleInventory;
		if (inventory[itemName] == undefined)
			inventory[itemName] = 0;
		inventory[itemName] += amount;
	},

	removeFromInventory: function (itemName, amount) {
		if (this.visibleInventory[itemName] != undefined) {
			if (this.visibleInventory[itemName] > 0) {
				if (amount <= this.visibleInventory[itemName]) {
					this.visibleInventory[itemName] -= amount;
					return;
				}
				else {
					amount -= this.visibleInventory[itemName];
					this.visibleInventory[itemName] = 0;
				}
			}
		}
		if (this.invisibleInventory[itemName] != undefined) {
			if (this.invisibleInventory[itemName] > 0) {
				if (amount <= this.invisibleInventory[itemName]) 
					this.invisibleInventory[itemName] -= amount;
				else 
					this.invisibleInventory[itemName] = 0;
			}
		}
	}, 

	checkInventory: function (itemName, amount) {
		if (this.visibleInventory[itemName] != undefined) {
			if (this.visibleInventory[itemName] > 0) {
				if (amount <= this.visibleInventory[itemName]) 
					return true;
				else 
					amount -= this.visibleInventory[itemName];
			}
		}
		if (this.invisibleInventory[itemName] != undefined) {
			if (this.invisibleInventory[itemName] > 0) 
				return amount <= this.invisibleInventory[itemName]; 
		}
		return false;
	}, 

	matchTextualInput: function (text) {
		var normalizedText = text.trim().toLowerCase();
		for (var expectedText in this.matchTextualInputCallbacks) {
			if (normalizedText == expectedText.trim().toLowerCase()) {
				this.matchTextualInputCallbacks[expectedText]();
				return;
			}
		}
		this.defaultCallback();
	}, 

	formatRemainingTime: function(totalTimeInMs) {
		var totalTimeInS = Math.ceil(totalTimeInMs / 1000);
		var seconds = totalTimeInS % 60;
		var totalTimeInM = Math.floor(totalTimeInS / 60);
		var minutes = totalTimeInM % 60;
		var totalTimeInH = Math.floor(totalTimeInM / 60);
		var hours = totalTimeInH;
		if (hours > 0) 
			return hours + ":" + minutes + ":" + seconds;
		else if (minutes > 0)
			return minutes + ":" + seconds;
		else 
			return seconds;
	}, 

	switchScreen: function (selector) {
		$("#startScreen, #playScreen").not(selector).css("display", "none");
		$(selector).css("display", "block");
	}, 

	newBackgroundImage: function (backgroundImage) {	
		var setBackgroundImageWhenAvailable = function(backgroundImageAsCssValue) {
			$("#darkenBackground").stop(true, false).fadeTo(this.animationDuration, 0);
			$(".background").stop(true, true);
			$(".background0").css("display", "block").css("opacity", "1").css("background-image", backgroundImageAsCssValue).html(""); 
			$(".background1").css("display", "block").fadeOut(runtime.animationDuration, function () {
				$(".background").toggleClass("background0").toggleClass("background1");
			});
		}
		if (backgroundImage == undefined || backgroundImage == "") {
			setBackgroundImageWhenAvailable("none");
		}
		else {
			$("#darkenBackground").delay(this.darkenBackgroundIfImageWasNotLoadAfter).fadeTo(this.animationDuration, 0.8);
			var bgImg = new Image();
			bgImg.onload = function () {
				setBackgroundImageWhenAvailable("url('" + bgImg.src + "')");
			};
			bgImg.src = backgroundImage;
		}
	}
};

$(document).ready(function() {
	$("title").html(generated.adventureGameName);
	$("#startScreenText").html(generated.adventureGameName);
	$("#matchTextualInputSubmit").click(function () {
		runtime.matchTextualInput($("#matchTextualInputField").val());
	});
	$("#matchTextualInputField").keypress(function (e) {
		if(e.keyCode == 13)
			runtime.matchTextualInput($("#matchTextualInputField").val());
	});
	$("#startScreenSubmit").click(function () {
		runtime.entry();
	});
	runtime.newBackgroundImage("./images/startScreenBackground.svg");
});

